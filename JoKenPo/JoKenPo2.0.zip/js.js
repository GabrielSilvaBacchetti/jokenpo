var jogada, VitóriaJogador=0, Empate=0, ComputadorGanhou=0, Ganhador;

function pedra(){
	jogada = 1;
}

function papel(){
	jogada = 2;
}

function tesoura(){
	jogada = 3;
}
function jogar(){
	var jogadaia = Math.random()


		    if(jogada < 0.33){
		    	jogadaia = 1;
		    }
		    else if(jogada <= 0.66){
		    	jogadaia = 2;
		    }
		    else{
		        jogadia = 3;
		    }


   }

     if(jogada === pedra)&&(jogadaia === tesoura)||(jogada === tesoura)&&(jogadaia === papel)||(jogada === papel)&&(jogadia === pedra){
	    alert("Vitória")
	 }  
	 else if(jogada === pedra)&&(jogadaia === papel)||(jogada === papel)&&(jogadaia === tesoura)||(jogada === tesoura)&&(jogadaia === pedra){
	 	alert("Perdeu")
	 }
	 else(jogada === jogadaia){
        alert("Empate") 
	 }


	if(Ganhador === 'Vitória'){
       VitóriaJogador+=
	}
	else if(Ganhador === 'Perdeu'){
       ComputadorGanhou+=
	}
	else{
		Empate+=
	}

	document.getElementById("jogada").innerHTML = jogada;
	document.getElementById("jogadaia").innerHTML = jogadaia ;
	document.getElementById("VitóriaJogador").innerHTML = VitóriaJogador;
	document.getElementById("ComputadorGanhou").innerHTML = ComputadorGanhou;
	document.getElementById("PartidasEmpatadas").innerHTML = PartidasEmpatadas;
	document.getElementById("Ganhador").innerHTML = Ganhador;
